#!/usr/bin/env groovy
println "Hello World"

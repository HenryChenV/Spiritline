// this used to take ages
void foo() throws xxxxxxxxxxxxxxxxxxxxxx{ }

{ :old_syntax => 'ok' }
{ 'stings as key' => 'should be ok' }
{ new_syntax: 'broken until now' }
{ withoutunderscore: 'should be ok' }
{ _underscoreinfront: 'might be ok, if I understand the pygments code correct' }
